# Backend - CFL 401 MVP
Carpeta destinada al desarrollo del backend que se conectará con el frontend de Next.js.
- Pendiente de definir lenguaje (Node.js/Python/PHP) y base de datos (PostgreSQL/MongoDB).
- Debe contemplar endpoints protegidos por JWT validados según la matriz de permisos de usuarios (Administrador, Directivo, Preceptor, Docente).