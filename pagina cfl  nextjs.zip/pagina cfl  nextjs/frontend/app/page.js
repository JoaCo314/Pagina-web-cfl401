export default function Home() {
  return (
    <div>
      {/* TOP BAR */}
      <div style={{ background: '#122A45', color: '#FFF', fontSize: '13.5px', padding: '9px 0' }}>
        <div style={{ maxWidth: '1180px', margin: '0 auto', padding: '0 28px', display: 'flex', justifyContent: 'space-between', flexWrap: 'wrap' }}>
          <div style={{ display: 'flex', gap: '14px' }}>
            <span>• Cursos 100% gratuitos</span>
            <span>• Modalidad presencial</span>
          </div>
          <span>Azul, Buenos Aires</span>
        </div>
      </div>

      {/* HEADER / NAV */}
      <header style={{ background: '#FFF', borderBottom: '1px solid rgba(18,42,69,0.1)', position: 'sticky', top: 0, zIndex: 50 }}>
        <nav style={{ maxWidth: '1180px', margin: '0 auto', padding: '16px 28px', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
            <div style={{ width: '46px', height: '46px', borderRadius: '50%', background: '#1B3A5C', display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#fff', fontWeight: 'bold', fontSize: '12px' }}>401</div>
            <div>
              <div style={{ fontFamily: 'Poppins, sans-serif', fontSize: '16.5px', fontWeight: '700', color: '#122A45' }}>Centro de Formación Laboral 401</div>
              <div style={{ fontSize: '11.5px', color: '#3E8FCC', fontWeight: '600', textTransform: 'uppercase' }}>Azul</div>
            </div>
          </div>
          <div style={{ display: 'flex', gap: '24px', fontSize: '14.5px', fontWeight: '500' }}>
            <a href="#cursos">Cursos</a>
            <a href="#docentes">Docentes</a>
            <a href="#noticias">Noticias</a>
            <a href="/admin" style={{ color: '#3E8FCC', fontWeight: 'bold' }}>Panel Admin / Roles</a>
          </div>
        </nav>
      </header>

      {/* HERO SECTION */}
      <section style={{ background: 'linear-gradient(180deg, #122A45 0%, #1B3A5C 100%)', color: '#FFF', padding: '56px 28px 64px' }}>
        <div style={{ maxWidth: '1180px', margin: '0 auto' }}>
          <div style={{ background: 'rgba(255,255,255,0.12)', padding: '7px 14px', borderRadius: '20px', width: 'fit-content', fontSize: '13px', fontWeight: '600', marginBottom: '22px' }}>
            Preinscripción 2026 abierta
          </div>
          <h1 style={{ fontSize: '38px', maxWidth: '640px', marginBottom: '16px' }}>Capacitate en un oficio, gratis y cerca de casa.</h1>
          <p style={{ fontSize: '16.5px', opacity: 0.85, maxWidth: '520px', marginBottom: '28px' }}>
            Cursos presenciales dictados por profesionales en actividad. Elegí tu curso, consultá cupos y horarios, e inscribite en minutos.
          </p>
          <a href="#cursos" style={{ background: '#3E8FCC', color: '#122A45', padding: '14px 26px', borderRadius: '4px', fontWeight: '700', textDecoration: 'none', display: 'inline-block' }}>
            Ver oferta de cursos
          </a>
        </div>
      </section>

      {/* SECCIÓN CURSOS */}
      <section id="cursos" style={{ padding: '60px 28px', maxWidth: '1180px', margin: '0 auto' }}>
        <h2 style={{ fontSize: '28px', color: '#122A45', marginBottom: '24px' }}>Cursos y Capacitaciones 2026</h2>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))', gap: '20px' }}>
          
          <div style={{ border: '1.5px solid rgba(18,42,69,0.12)', borderRadius: '8px', padding: '22px', background: '#FFF' }}>
            <h3 style={{ fontSize: '17.5px', color: '#122A45', marginBottom: '8px' }}>Electricidad Domiciliaria</h3>
            <p style={{ fontSize: '13.5px', opacity: 0.68, marginBottom: '14px' }}>Instalaciones, seguridad eléctrica y normativa vigente. Nivel inicial.</p>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', borderTop: '1px solid rgba(18,42,69,0.08)', paddingTop: '14px' }}>
              <span style={{ fontWeight: '700', color: '#1F7A4C' }}>Gratuito</span>
              <span style={{ fontSize: '13.5px', color: '#1B3A5C', fontWeight: '700' }}>Cupos limitados</span>
            </div>
          </div>

          <div style={{ border: '1.5px solid rgba(18,42,69,0.12)', borderRadius: '8px', padding: '22px', background: '#FFF' }}>
            <h3 style={{ fontSize: '17.5px', color: '#122A45', marginBottom: '8px' }}>Carpintería General</h3>
            <p style={{ fontSize: '13.5px', opacity: 0.68, marginBottom: '14px' }}>Herramientas manuales y eléctricas, armado de estructuras básicas.</p>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', borderTop: '1px solid rgba(18,42,69,0.08)', paddingTop: '14px' }}>
              <span style={{ fontWeight: '700', color: '#1F7A4C' }}>Gratuito</span>
              <span style={{ fontSize: '13.5px', color: '#1B3A5C', fontWeight: '700' }}>Cupos limitados</span>
            </div>
          </div>

        </div>
      </section>
    </div>
  );
}