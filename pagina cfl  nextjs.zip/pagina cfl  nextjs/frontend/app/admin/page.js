'use client';
import { useState } from 'react';

export default function AdminPanel() {
  // Simulación de roles para testear con el grupo: 'admin', 'directivo', 'preceptor', 'docente'
  const [role, setRole] = useState('admin');

  return (
    <div style={{ padding: '40px', maxWidth: '1000px', margin: '0 auto', fontFamily: 'sans-serif' }}>
      <h1 style={{ color: '#122A45' }}>Panel de Administración - CFL 401</h1>
      <p style={{ marginBottom: '20px', color: '#555' }}>Simulador de permisos para el equipo de desarrollo:</p>
      
      {/* Selector de Roles dinámico */}
      <div style={{ marginBottom: '30px', padding: '15px', background: '#EAF3FA', borderRadius: '8px' }}>
        <label style={{ fontWeight: 'bold', marginRight: '10px' }}>Seleccionar Rol Activo:</label>
        <select value={role} onChange={(e) => setRole(e.target.value)} style={{ padding: '8px', borderRadius: '4px' }}>
          <option value="admin">Administrador (Acceso total)</option>
          <option value="directivo">Directivo (Modifica profesores y cursos)</option>
          <option value="preceptor">Preceptor (Asistencia, alumnos y cursos)</option>
          <option value="docente">Docente (Solo cursos asignados)</option>
        </select>
      </div>

      {/* Vistas según Permisos (Req. 4 y 5 del PDF) */}
      <div style={{ border: '1px solid #ccc', padding: '20px', borderRadius: '8px' }}>
        {role === 'admin' && (
          <div>
            <h3 style={{ color: '#122A45' }}>Vista: Administrador</h3>
            <p>✔ Control total: Crear, editar y eliminar cualquier curso[cite: 1].</p>
            <p>✔ Asignar docentes y crear nuevos usuarios con privilegios administrativos[cite: 1].</p>
            <button style={{ background: '#122A45', color: '#fff', padding: '10px 15px', border: 'none', borderRadius: '4px', cursor: 'pointer' }}>+ Crear Nuevo Curso o Usuario</button>
          </div>
        )}

        {role === 'directivo' && (
          <div>
            <h3 style={{ color: '#122A45' }}>Vista: Directivos</h3>
            <p>✔ Gestión y modificación de profesores y oferta de cursos institucionales[cite: 1].</p>
          </div>
        )}

        {role === 'preceptor' && (
          <div>
            <h3 style={{ color: '#122A45' }}>Vista: Preceptor</h3>
            <p>✔ Carga y control de asistencia (presentes/ausentes) de alumnos[cite: 1].</p>
            <p>✔ Visualización de listado de cursos, profesores a cargo y nómina de estudiantes.</p>
          </div>
        )}

        {role === 'docente' && (
          <div>
            <h3 style={{ color: '#122A45' }}>Vista: Docente</h3>
            <p style={{ color: '#B23A3A', fontWeight: 'bold' }}>🔒 Acceso restringido exclusivamente a los cursos asignados.</p>
            <p>✔ Modificación de contenidos y programas de los cursos propios, sin permisos de eliminación ni de otros docentes[cite: 1].</p>
          </div>
        )}
      </div>
    </div>
  );
}